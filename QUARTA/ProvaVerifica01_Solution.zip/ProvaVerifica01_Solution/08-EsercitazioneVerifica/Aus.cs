﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08_EsercitazioneVerifica
{
    class Aus
    {
        public static string txtCheck = "";
        public static string txtAuto = "";

        public Aus(string txtCheckBox, string txtListBox)
        {
            txtCheck = txtCheckBox;
            txtAuto = txtListBox;
        }
    }
}
