﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _08_EsercitazioneVerifica
{
    public partial class Figlia1 : Form
    {
        public string interni = "";
        public string auto = "";

        public Figlia1()
        {
            InitializeComponent();
        }

        private void Figlia1_CheckControl(object sender, EventArgs e)
        {
            CheckBox chk = (CheckBox)sender;
            if(chk.Checked == true)
            {
                interni = chk.Text;
            }
            else
            {
                interni = "";
            }
            Aus a = new Aus(interni, auto);
        }

        private void Figlia1_ChangeValue(object sender, EventArgs e)
        {
            ListBox lst = (ListBox)sender;
            auto = lst.Text;
            Aus a = new Aus(interni, auto);
        }
    }
}
