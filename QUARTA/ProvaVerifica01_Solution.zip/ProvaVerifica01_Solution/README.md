_Corneanu George Alexandru_

### Esercitazione Verifica